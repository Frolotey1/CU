# CU | ConsoleUtility / Deutsch KonsoleDienstProgramm 

![License](https://img.shields.io/github/license/Frolotey1/CU-ConsoleUtility) ![GitHub release (latest by date)](https://img.shields.io/github/v/release/Frolotey1/CU-ConsoleUtility)

# English Description / Die Deutsche Beschreibenung
You can watch the full description for the project in / Sie konnen sehen eine volle beschreibenung fur projekt im: 

- 🇩🇪 **Deutsch** → [READMEDeutsch.md](./READMEDeutsch.md)
- 🇬🇧 **English** → [READMEEnglish.md](./READMEEnglish.md)

# License
This project works under `GPL-2.0 license`
